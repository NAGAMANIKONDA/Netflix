
## Start application by following steps

1. npm install
2. npm start